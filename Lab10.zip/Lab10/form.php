<!-- form.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Favorite City Form</title>
</head>
<body>
    <h2>Enter Your Favorite City</h2>
    <form action="welcom.php" method="POST">
        <label for="city">Favorite City:</label>
        <input type="text" id="city" name="city" required>
        <button type="submit">Submit</button>
    </form>
</body>
</html>
